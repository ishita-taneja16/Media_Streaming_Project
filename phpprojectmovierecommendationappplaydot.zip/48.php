<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br>

<center><img src="https://cdn.blogo.it/tv1cYbZ_PbgQolX6SogktnZmHew=/640x384/smart/https://www.blogo.it/app/uploads/sites/3/2022/11/inside-trailer-e-anticipazioni-del-thriller-psicologico-con-willem-dafoe-ladro-darte-2.png" alt="not available" style="width:1000px;height:400px;"> </center>
<center><p style =font-size:40px;><u>Inside</u></center> </p>
<button onclick="document.location='https://youtu.be/DjODCllZj4w'">Watch Trailer</button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>Inside is a 2023 psychological thriller film written by Ben Hopkins and directed by Vasilis Katsoupis in his feature directorial debut.[4] The film follows an art thief (Willem Dafoe) who is trapped inside a luxury penthouse, slowly losing his grip on reality.
Inside had its world premiere at the 73rd Berlin International Film Festival on 20 February 2023. The film was released theatrically in Greece on 10 March 2023 by Tulip Entertainment, in Belgium on 15 March 2023 by Sony Pictures Belgium, and in Germany on 16 March 2023 by SquareOne Entertainment.<br><br>
<u>~Director</u> Vasilis Katsoupis
<br><br>
<u>~Writers</u> 
                Ben Hopkins
<br><br>
<u>~Stars</u> Willem Dafoe as Nemo<br>
Gene Bervoets as owner<br>
Eliza Stuyck as Jasmine</p>
</BODY>
</HTML>

<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>