<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Slideshow</title>
    <style>
        #slideshow {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
<body bgcolor="black">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font>

<p align="right"><button>Movies</button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button>TV Shows</button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">       
<option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option>Drama</option>
<option>Mystery</option>
<option>Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" value="search" name="search">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="un4.jpg" height="50px" width="50px">
</p> <br><br>
<center>
    <img id="slideshow" src="idphoto.jpg" alt="Image 1" height="100px" width="100px"></center>
    
    <script>
        const images = ["idphoto.jpg", "un4.jpg", "id photo.jpg", "image4.jpg"];
        let currentIndex = 0;

        function changeImage() {
            const slideshow = document.getElementById('slideshow');
            slideshow.src = images[currentIndex];
            currentIndex = (currentIndex + 1) % images.length;
            setTimeout(changeImage, 2000); // Change image every 2 seconds (2000 milliseconds)
        }

        // Start the slideshow
        changeImage();
    </script>
</body>
</html>
