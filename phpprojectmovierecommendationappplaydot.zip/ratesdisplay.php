<HTML>
<BODY bgcolor="black", text="white">

<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> <center>
<br><br><br><font color="white" size="7" ><b>Your Rates</b></font><br><br><br><br><br><font size="5">
<?php
// attempt a connection
$conn = new mysqli("localhost", "root", "", "playdot");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql ="SELECT USERNAME , MOVIE FROM rating_movies WHERE USERNAME ='ishita'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
 echo $row['MOVIE'] .  "\n";
echo '<form method="post" action="settings.php">';
echo '<br><br><input type="submit" value="Back"><br>';
 }
} else {
 echo "ERROR: Could not execute $sql. ";
}
// close connection
$conn->close();
?>
</font></center></html>