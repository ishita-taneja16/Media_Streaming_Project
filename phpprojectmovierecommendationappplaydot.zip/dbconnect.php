<?php
$name= $_POST['first'];
$like= $_POST['genre'];
$movie= $_POST['mov'];

$mysqli = new mysqli("localhost", "root", "", "playdot");
if($mysqli ===false)
{
die("Error: Could not connect. ".mysqli_connect_error());
}
$sql="INSERT INTO rating_movies
VALUES ('$name', '$movie', '$like')";
if ($mysqli->query($sql) === true) {
echo "Your action is now added....";
}

else
{
echo "Error: could not execute $sql." .$mysqli->error;
}
$mysqli->close();
?>
