<html>
<head>
<script language="javascript">
  function validateForm() {
    const pwdInput = document.getElementById('pwd');
    const pwd = pwdInput.value;
    }
</script></head>
</head>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">Unlimited Movies, TV Shows, <br>Web Series and more.<br></b></font>
<font style="consolas", size="4">Watch anywhere. Cancel anytime. <br>Ready to watch? <br>Continue by filling your details or signup to enjoy. 
<form method="post" action="ss.php"></font>
<font style="Arial", color="white">
<center><br><br>
Username: <input type="text" id="username" name="name" /required><br><br>
Password: <input type="password"  name="pwd" /required><br>
<br><p> <a href="mobile.php" style="color: white">Forgot password </a><br><br>
<table border="4" bordercolor= "red" bgcolor= "red" width= "50%">
<tr>
<th><font style="Arial", color="white">
<button>Sign In</button></th></font>
</tr>
</table>
<font size="3", color="white">
<p>Don't have an account? <a href="fdf.php" style="color: #ADD8E6 ">Click to Sign Up</a></p></font>

</form></center><p align="left">

<br><br><br><br>
<hr size="10", color="pink" >
<font style="consolas" color="red" size="5">No. of users logged in: 
    <div id="counter">0</div>

    <script>
        // Function to increment the number
        function incrementNumber() {
            var counter = document.getElementById("counter");
            var currentNumber = parseInt(counter.innerHTML);
            counter.innerHTML = currentNumber + 1;
        }

        // Set an interval to call the incrementNumber function every 2 seconds
        setInterval(incrementNumber, 500); // 2000 milliseconds = 2 seconds
    </script>
</hr>
</font>




</body>
</html>