-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2024 at 02:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `playdot`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie_naam`
--

CREATE TABLE `movie_naam` (
  `SNO` int(10) NOT NULL,
  `MOVIES` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movie_naam`
--

INSERT INTO `movie_naam` (`SNO`, `MOVIES`) VALUES
(1, 'The Nun2'),
(2, 'Tu Jhoothi Mai Makkar'),
(3, 'Jawan'),
(4, 'Buhe Bariyan'),
(5, 'Dream Girl2'),
(6, 'Big Bang Theory'),
(7, 'Friends'),
(8, 'Om Shanti Om'),
(9, 'Badrinath Ki Dulhaniya'),
(10, 'Taare Zameen Par'),
(11, 'Chor Nikal Ke Bhaga'),
(12, 'Agneepath'),
(13, 'Gangs Of Wassepur'),
(14, 'Barfi'),
(15, 'Lucifer'),
(16, 'The Vampire Diaries'),
(17, 'Greenhouse Academy'),
(18, 'Stranger Things'),
(19, 'Never Have I Ever'),
(20, 'Ginny & Georgia'),
(21, 'Wednesday'),
(22, 'Rocky Aur Rani Kii Prem Kahaan'),
(23, 'Satyaprem Ki Katha'),
(24, 'Tu Jhoothi Main Makkar'),
(25, 'Through My Window '),
(26, 'Kushi'),
(27, 'Bawaal'),
(28, 'Sita Ramam'),
(29, 'Jugjugg Jeeyo '),
(30, 'Gehraiyaan'),
(31, 'Lover'),
(32, 'Freddy'),
(33, 'Radhe Shyam'),
(34, 'Brahmastra'),
(35, 'Subhedar'),
(36, 'Jailer'),
(37, 'Pathaan'),
(38, 'Aneethi'),
(39, 'Pichikkaran2'),
(40, 'Bhola Shankar'),
(41, 'The Teacher'),
(42, 'Jaisa'),
(43, 'Darlings'),
(44, 'Gangubai Kathiawadi'),
(45, ' A Thursday'),
(46, 'Qala'),
(47, 'Doctor G'),
(48, 'Inside'),
(49, 'She came to me '),
(50, 'Reptile'),
(51, 'It Lives Inside'),
(52, 'Expend4bles'),
(53, 'Kolai'),
(54, 'To Catch A Killer'),
(55, 'The Wonder'),
(56, 'The Contractor'),
(57, 'Memory'),
(58, 'Luckiest Girl Alive'),
(59, 'Barbarian'),
(60, 'The Invitation'),
(61, 'Shut In'),
(62, 'Boy Next Door'),
(63, 'Who Killed Sara?'),
(64, 'Reptile'),
(65, 'Control Z'),
(66, 'Truth or Dare'),
(67, 'Choose or Die'),
(68, 'Dear Child'),
(69, 'A Haunting in Venice'),
(70, 'Money Heist'),
(71, 'Squid Game'),
(72, 'Tarak Mehta Ka Ooltah Chashma'),
(73, 'Yeh Rishta Kya Kehlata Hai'),
(74, 'Roadies'),
(75, 'Kaisi Yeh Yariyaan'),
(76, 'The Office');

-- --------------------------------------------------------

--
-- Table structure for table `rating_movies`
--

CREATE TABLE `rating_movies` (
  `USERNAME` varchar(20) NOT NULL,
  `MOVIE` varchar(40) NOT NULL,
  `LIKE` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rating_movies`
--

INSERT INTO `rating_movies` (`USERNAME`, `MOVIE`, `LIKE`) VALUES
('', '', ''),
('', '', ''),
('', '', ''),
('', '', ''),
('shruti', 'rocky aur raani ki prem kahani', '⭐5'),
('ishita', 'rocky aur raani ki prem kahani', '⭐4'),
('abcde', 'the nun 2 ', '⭐5'),
('', '', 'selec'),
('ishita', 'Juggjug Jeeyo', '⭐5');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `FIRSTNAME` varchar(20) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `STATE` varchar(30) NOT NULL,
  `GENDER` varchar(10) NOT NULL,
  `PHONE` int(10) NOT NULL,
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`FIRSTNAME`, `EMAIL`, `STATE`, `GENDER`, `PHONE`, `USERNAME`, `PASSWORD`) VALUES
('ishita', 'ishitataneja016@gmail.com', 'Punjab', 'Female', 2147483647, 'ishita', 'ishita'),
('shruti', 'ishitataneja016@gmail.com', 'Punjab', 'Female', 2147483647, 'shruti', 'shruti');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
