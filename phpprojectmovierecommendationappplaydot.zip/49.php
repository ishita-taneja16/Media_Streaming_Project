<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br>

<center><img src="https://cdn.firstcuriosity.com/wp-content/uploads/2023/01/12170959/IMG_COM_20230112_1701_06_0482-1024x768.jpg" alt="not available" style="width:1000px;height:400px;"> </center>
<center><p style =font-size:40px;><u>She Came To Me</u></center> </p>
<button onclick="document.location='https://youtu.be/EdfEv2ZwrFs'">Watch Trailer</button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>She Came to Me is a 2023 American romantic comedy film written and directed by Rebecca Miller. It stars Peter Dinklage, Marisa Tomei, Joanna Kulig, Brian d'Arcy James, and Anne Hathaway.

It had its world premiere at the 73rd Berlin International Film Festival on February 16, 2023, and was released on October 6, 2023, by Vertical Entertainment.<br><br>
<u>~Director</u> Rebecca Miller
<br><br>
<u>~Writers</u> 
                Rebecca Miller
<br><br>
<u>~Stars</u>
Peter Dinklage as Steven Lauddem <br>
Anne Hathaway as Patricia Jessup-Lauddem<br>
Marisa Tomei as Katrina Trento<br>
Evan Ellison as Julian Jessup<br>
Harlow Jane as Tereza Szyskowski<br>
Joanna Kulig as Magdalena Szyskowski<br>
Brian d'Arcy James as Trey Ruffa<br>
Judy Gold as Susan Shaw<br>
Gregg Edelman as Duftin Haverford
Aalok Mehta as Anton Gatner<br>
Chris Gethard as Carl<br>
Dale Soules as Aunt Moxie<br>
Jen Ponton as Elodie</p>
</BODY>
</HTML>

<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>