<html>
<head>
</head>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="10"> GOODBYE! <br><br><br><br></b></font>
<font style="consolas", size="7">
<?php
$name=$_POST['first'];
$new=$_POST['number1'];
$mysqli = new mysqli("localhost", "root", "", "playdot");
if($mysqli ===false)
{
die("Error: Could not connect. ".mysqli_connect_error());
}
$sql = "DELETE FROM registration WHERE
username = '$name'";
if ($mysqli->query($sql) === true) {
 echo 'Your Account Has Been Deleted';
}

// close connection
$mysqli->close();
?>
</font>
<form>
<br><br><BUTTON ><a href="playdot.php">Submit</a></button>
</form>
</html>