<html>
 <body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">Unlimited Movies, TV Shows, <br>Web Series and more.<br></b></font>
<font style="consolas", size="4">Watch anywhere. Cancel anytime. <br>Ready to watch? <br>Continue by filling your details or signup to enjoy. 
</font>
<font style="Arial", color="white">
<br><br></center>
<?php
$name=$_POST['first'];
$mail=$_POST['email'];
$option=$_POST['option'];
$gender=$_POST['gender'];
$number=$_POST['phone'];
$name1=$_POST['name'];
$pass=$_POST['pwd'];
$mysqli = new mysqli("localhost", "root", "", "playdot");
if($mysqli ===false)
{
die("Error: Could not connect. ".mysqli_connect_error());
}
$sql="INSERT INTO registration
VALUES ('$name', '$mail', '$option','$gender','$number','$name1','$pass')"; 

if ($mysqli->query($sql) === true) {
echo "REGISTERED SUCCESSFULLY... CLICK BELOW TO CONTINUE";
}

else
{
echo "Error: could not execute $sql." .$mysqli->error;
}
$mysqli->close();
?>
<FORM method="post" action="playdot.php">
<br><input type="submit" value=" Click">
</form>
</body>
</html>