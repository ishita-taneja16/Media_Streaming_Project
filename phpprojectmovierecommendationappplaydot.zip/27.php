<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br><center>

<img src="https://static.toiimg.com/photo/101510855.jpeg" alt="not available" style="width:900px;height:300px;">
<center><p style =font-size:40px;><u>Bawaal</u></center> </p></center>
<button onclick="document.location='https://youtu.be/NyeG2mLVCS4?si=KscYlt2LiTZJMlmE'">Watch Trailer</button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>A small-town man who falls in love with the most beautiful girl in town. He wants to marry her one day because marrying her can raise his social position..<br>
<u>~Director</u> Nitesh Tiwari
<br>
<u>~Writers</u> Piyush Gupta : Shreyas Jain : Nikhil Mehrotra
<br>
<u>~Stars</u> Varun Dhawan : Janhvi Kapoor : Manoj Pahwa</p>
</BODY>
</HTML>

<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>