<html>
<head>
<script>
function al() {
var a= document.getElementById("continue").value;
prompt("OTP has sent to your number... Please enter your OTP.");
}
</script>
</head>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">Unlimited Movies, TV Shows, <br>Web Series and more.<br></b></font>
<font style="consolas", size="4">Watch anywhere. Cancel anytime. <br>Ready to watch? <br>Continue by filling your details or signup to enjoy.
<form method="post" action="update.php" onsubmit="return al();"></font>
<font style="Arial", color="white">
<center><br><br>
 enter your contact number <br>
 <input type="text" id="username" name="number" /required><br><br>

<table border="4" bordercolor= "red" bgcolor= "red" width= "50%">
<tr>
<th><font style="Arial", color="white">
<input type="submit" value="Continue" id="continue" ></th></font>
</tr>
</table>
<br><br><br><br>
<hr size="10", color="pink" >
<font style="consolas" color="red" size="5">No. of users logged in:
    <div id="counter">0</div>

    <script>
        // Function to increment the number
        function incrementNumber() {
            var counter = document.getElementById("counter");
            var currentNumber = parseInt(counter.innerHTML);
            counter.innerHTML = currentNumber + 1;
        }

        // Set an interval to call the incrementNumber function every 2 seconds
        setInterval(incrementNumber, 500); // 2000 milliseconds = 2 seconds
    </script>
</hr>
</font>




</html></body>