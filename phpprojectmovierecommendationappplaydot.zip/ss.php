<html>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">Unlimited Movies, TV Shows, <br>Web Series and more.<br></b></font>
<font style="consolas", size="4">Watch anywhere. Cancel anytime. <br>Ready to watch? <br>Continue by filling your details or signup to enjoy. 
</font>
<font style="Arial", color="white">
<br><br></center>
<?php
$name1=$_POST['name'];
$pass=$_POST['pwd'];
// Create connection
$conn = new mysqli("localhost", "root", "", "playdot");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql ="SELECT USERNAME , PASSWORD FROM registration WHERE USERNAME ='$name1'AND PASSWORD ='$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
echo "RECORDS MATCHED";
    echo '<form method="post" action="play2.php">';
echo '<input type="submit" name="click"><br>';
  }
} else {
  echo "RECORDS  NOT MATCHED ........ TRY AGAIN";
    echo '<form method="post" action="playdot.php">';
    echo '<input type="submit" name="click"><br>';

  }
$conn->close();
?>


</form>
</body>
</html>