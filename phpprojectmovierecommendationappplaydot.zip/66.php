<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></form>
</p><br><br>
<center><img src="http://filmofilia.com/wp-content/uploads/2012/04/Truth-or-Dare_08.jpg" alt="not available" style="width:900px;height:300px;">
<center><p style =font-size:40px;><u>Truth or Dare</u></center> </p></center>
<button><a href="https://youtu.be/Cgnk3MLw9TM">Watch Trailer</a></button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>  At a bar, Olivia meets a man named Carter, who invites the group to party at an abandoned church. There, Carter suggests they play truth or dare. During the game, their friend Tyson Curran reveals that Olivia has a crush on Lucas Moreno, Markie's boyfriend, which she denies. Carter admits that he tricked them into playing a supernatural version of the game and warns them to do whatever the game asks or they will be killed.<br>
<u>~Director</u>  Jason Blum
<br>
<u>~Writers</u> Michael Reisz, Jillian Jacobs, and Chris Roach
<br>
<u>~Stars</u> Lucy Hale, Tyler Posey, Violett Beane, Hayden Szeto, Sophia Taylor Ali, and Landon Liboiron 	</p>
</BODY>
</HTML>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>


<img src="playd.jpg" width="1250px" height="150px">
</body>
</html>