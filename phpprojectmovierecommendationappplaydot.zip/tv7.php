<HTML>
<BODY bgcolor="black", text="white">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font>

<p align="right"><button>Movies</button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">       
<option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          
<img src="un4.jpg" height="50px" width="50px">
</p> <br><br>
<center><img src="https://picfiles.alphacoders.com/159/thumb-1920-159671.jpg" alt="not available" style="width:900px;height:300px;">
<center><p style =font-size:40px;><u>The Office</u></center> </p></center>
<button><a href="https://youtu.be/LHOtME2DL4g">Watch Trailer</a></button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p> The longest-running version of the series, the US adaptation, ran for nine seasons on the NBC Television Network from 2005 to 2013, with a total of 201 episodes. According to Nielsen Ratings as of April 2019, the US version of The Office was the No. 1 streamed show on Netflix in the United States<br>
<u>~Director</u>  Ricky Gervais and Stephen Merchant 
<br>
<u>~Stars</u> --	</p>
</BODY>
</HTML>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>


<img src="playd.jpg" width="1250px" height="150px">
</body>
</html>