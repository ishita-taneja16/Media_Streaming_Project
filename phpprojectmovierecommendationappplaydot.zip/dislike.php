<html>
<body>
<form method="post" action="dbconnect2.php">
Please give your feedback on how we can improve<br>
Username<input type="text" id="first" name="first"><br>
Movie name<input type="text" id="mov" name="mov"><br>

<input type="submit"  name="dis" id="dis" value="  👎 ">
</form>
</html>