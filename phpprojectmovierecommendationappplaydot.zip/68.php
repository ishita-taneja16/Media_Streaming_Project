<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></form>
</p><br><br></a>
<center><img src="https://www.coffeeandbooks.co.uk/wp-content/uploads/2020/12/Dear-Child-by-Romy-Hausmann.jpg" alt="not available" style="width:900px;height:300px;">
<center><p style =font-size:40px;><u>Dear Child</u></center> </p></center>
<button><a href="https://youtu.be/nOuMvrHdgiE">Watch Trailer</a></button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p> A mysterious woman's escape from her harrowing captivity points investigators toward the dark truth behind an unsolved disappearance 13 years earlier.<br>
<u>~Director</u> Isabel Kleefeld
<br>
<u>~Writers</u>Romy Hausmann 
<br>
<u>~Stars</u> Kim Riedle, Naila Schuberth, Sammy Schrein, Hans Löw, Haley Louise Jones.	</p>
</BODY>
</HTML>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>


<img src="playd.jpg" width="1250px" height="150px">
</body>
</html>