<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br>

<center><img src="https://akm-img-a-in.tosshub.com/aajtak/images/story/202203/raadhae-sixteen_nine.png?size=948:533" alt="not available" style="width:1000px;height:400px;"> </center>
<center><p style =font-size:40px;><u>Radhe Shyam</u></center> </p>
<button onclick="document.location='https://youtu.be/ZAP6q_Zv-4g?si=Y7h99Lz0VgxI-dhp'">Watch Trailer</button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>In 1976, Vikramaditya, a palmist and disciple of Paramahamsa, predicts to Indian Prime Minsiter Indira Gandhi that soon she will declare emergency in the country. The prediction comes true and he becomes famous but has to leave the country for the same.<br>
<u>~Director</u>  K.K. Radhakrishna Kumar
<br>
<u>~Writers</u> Writers	
Abbas Dalal : Hussain Dalal : Madhan Karky
<br>
<u>~Stars</u> 
Prabhas : Pooja Hegde : Bhagyashree Patwardhan</p>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>
</body>
</html>