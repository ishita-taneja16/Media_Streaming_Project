<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br></a>
<center><img src="https://tse4.mm.bing.net/th?id=OIP.Xei6lvtxI05pZb5nzI2AzAHaEK&pid=Api&P=0&h=180" alt="not available" style="width:900px;height:300px;">
<center><p style =font-size:40px;><u>Tarak Mehta Ka Oolta Chashma</u></center> </p></center>
<button><a href="https://youtu.be/H3DtF0Xgtqo">Watch Trailer</a></button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p> The show also occasionally highlights social issues. Most of the episodes are based on Jethalal being stuck in
 a problem and Taarak Mehta, his best friend, whom he calls his "Fire Brigade", rescues him. Society members live 
like a family and help each other with their problems, to promote unity in diversity. The members of Gokuldham 
celebrate all the festivals and organize various events.<br>
<u>~Director</u>Asit Kumar Modi
<br>
<u>~Writers</u>Asit Kumar Modi
<br>
<u>~Stars</u> Dilip Joshi, Bhavya Gandhi, Disha Vakani, Amit Bhatt, Shailesh Lodha, Sachin Shroff, Neha Mehta, Munmun Dutta.	</p>
</BODY>
</HTML>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>


<img src="playd.jpg" width="1250px" height="150px">
</body>
</html>