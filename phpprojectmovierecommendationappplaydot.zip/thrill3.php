<HTML>
<BODY bgcolor="black", text="white">
<form action="search1.php" method="post">
<font style="consolas", color= "pink", size="6"><b>PLAYDOT</b></font> 

<p align="right"><button>Movies</button></center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button><a href="playtv.php">TV Shows</a></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <select name="genre" id="genre" onchange="redirectToSelected()">  
    <option>All categories</option>
<option value="play3.php">All</option>
<option value="play4.php">Romance</option>
<option value="drama.php">Drama</option>
<option value="mystery.php">Mystery</option>
<option value="thriller.php">Thriller</option>
</select>
         <script>
        function redirectToSelected() {
            const selectElement = document.getElementById('genre');
            const selectedValue = selectElement.value;

            if (selectedValue !== 'default') {
                window.location.href = selectedValue;
            }
        }
    </script>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" size="30" placeholder="search" name="search">
<input type="submit" value="🔍">
&nbsp;&nbsp;

<a  href="settings.php"><img src="un4.jpg" height="50px" width="50px"></a></form>
</p><br><br>

<center><img src="https://img.netzwelt.de/dw1600_dh900_sw1920_sh1080_sx0_sy0_sr16x9_nu2/picture/original/2023/05/benicio-del-toro-a-perfect-day-371878.jpeg" alt="not available" style="width:1000px;height:400px;"> </center>
<center><p style =font-size:40px;><u>Reptile</u></center> </p>
<button onclick="document.location='https://youtu.be/KS1cNkZ9o1U'">Watch Trailer</button>
<p style ="font-size:16px;direction:right;"><u>Overview</u></p>
<p>Reptile is a 2023 American crime thriller film directed by Grant Singer in his feature-film directorial debut, from a screenplay he co-wrote with Benjamin Brewer and Benicio del Toro, and a story he co-wrote with Brewer. The film stars del Toro in the lead role, alongside Justin Timberlake, Alicia Silverstone, Eric Bogosian, Ato Essandoh, Domenick Lombardozzi, and Michael Pitt.
It premiered at the Toronto International Film Festival on September 7, 2023, and was released in the United States in select theaters on September 22, 2023, before streaming on Netflix on September 29..<br><br>
<u>~Director</u> Grant Singer, Benicio del Toro
<br><br>
<u>~Writers</u> 
                Benicio del Toro, Brewer
<br><br>
<u>~Stars</u>
Del Toro and Justin Timberlake were cast in the film.[2] On September 30, 2021, Alicia Silverstone, Michael Pitt, Ato Essandoh, Frances Fisher, Eric Bogosian, Domenick Lombardozzi, Karl Glusman, Matilda Lutz, Owen Teague, and Catherine Dyer were cast in the film.[3] On October 14, 2021, Mike Pniewski, Thad Luckinbill, Sky Ferreira, James Devoti, and Michael Beasley were cast in the film.[4]</p>


<center>
<button onclick="document.location='images.png'">Download</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button onclick="document.location='buffering.png'">Stream</button>
<br><br>
<form method="post" action="like.php">
   <button type="submit" name="like"> FEEDBACK</button>
    </form> </center>
</BODY>
</HTML>