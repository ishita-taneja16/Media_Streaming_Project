<html>
<head>
</head>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">☹️</FONT>
<font  style="consolas", size="7"> WE'LL MISS YOU!!<br></b></font><br><br>
<font style="consolas", size="4">Please fill your details to deactivate your account...
<form method="post" action="delete1.php"></font>
<font style="Arial", color="white">
<center><br><br>
 Username &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="username" name="first" /required><br><br>
Password &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="password" id="username" name="number1" /required><br><br><br><br>
<table border="4" bordercolor= "red" bgcolor= "red" width= "50%">
<tr>
<th><font style="Arial", color="white">
<button>Continue</button></th></font>
</tr>
</table>
<br><br><br><br>
<hr size="10", color="pink" >
<font style="consolas" color="red" size="5">No. of users logged in:
    <div id="counter">0</div>

    <script>
        // Function to increment the number
        function incrementNumber() {
            var counter = document.getElementById("counter");
            var currentNumber = parseInt(counter.innerHTML);
            counter.innerHTML = currentNumber + 1;
        }

        // Set an interval to call the incrementNumber function every 2 seconds
        setInterval(incrementNumber, 500); // 2000 milliseconds = 2 seconds
    </script>
</hr>
</font>




</html></body>
