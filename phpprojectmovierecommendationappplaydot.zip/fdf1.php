<html>
<head>
   
    <script>
        function checkPasswords() {
            var password1 = document.getElementById("password1").value;
            var password2 = document.getElementById("password2").value;

            if (password1 != password2) {
                alert("Passwords donot match. Please enter a same password.");
                return false; // Prevent form submission
            }
            
            return true; // Allow form submission
        }
</script>
</head>
<body>
<body bgcolor=" #000000" >
<font style="consolas", color= "pink"><b><h1>PLAYDOT</h1></b></font>
<font style="Arial", color="white">
<CENTER> <b><font style="consolas", size="7">Unlimited Movies, TV Shows, <br>Web Series and more.<br></b></font>
<form method = "post" action="insert.php">
<center>
<div class="container">
<h1>Register Here</h1>
<p>Please fill in the details to create an account with us.</p>
<hr>
<b>Enter Name</b><input type="text" name="first">
</div><br>
<div><center>
<b>Enter Email</b><input type="text" name="email">
</div><br>
<div><center>
<b>State</b><select name="option">
<option value="State">State</option>
<option value="Andhra pradesh">Andhra pradesh</option>
<option value="Gujarat">Gujarat</option>
<option value="Kerala">Kerala</option>
<option value="Jammu & Kashmir">Jammu & Kashmir</option>
<option value="Punjab">Punjab</option>
<option value="Tamil Nadu">Tamil Nadu</option>
</select>
</div><br>
<div><center>
<b>Gender</b>
<input type="radio" value="Male" name="gender">Male
<input type="radio" value="Female" name="gender">Female
<input type="radio" value="Others" name="gender">Others
</div><br>
<div><center>
<b>Phone no </b><input type="text"  name="phone" size="10" >
</div><br>
<div><center>
<b>Enter UserName</b><input type="text"  name="name">
</div><br>
<b> Password</b>
<input type="password"  name="pwd" id="password1" /required><br><br>
<b>Confirm Password</b>
<input type="password"  name="confirm" id="password2" /required><br><br>
<hr>
<p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
<button>Register</button>

</div><br><br>
<center>
<div class="container signin">
<p><font color="white">Already have an account? <a href="playdot.php">Sign in</a></p></font>
</div>
</center>
</form>
</body>
</html>