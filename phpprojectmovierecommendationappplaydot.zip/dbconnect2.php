<?php
$name= $_POST['first'];

$movie= $_POST['mov'];
$dislike= $_POST['dis'];
$mysqli = new mysqli("localhost", "root", "", "playdot");
if($mysqli ===false)
{
die("Error: Could not connect. ".mysqli_connect_error());
}
$sql="INSERT INTO rating_movies
VALUES ('$name', '$movie', '$like', '$dislike')";
if ($mysqli->query($sql) === true) {
echo "Your action is now added....";
}

else
{
echo "Error: could not execute $sql." .$mysqli->error;
}
$mysqli->close();
?>