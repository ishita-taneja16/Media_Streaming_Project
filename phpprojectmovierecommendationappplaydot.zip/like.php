<HTML>
<HEAD>
</HEAD>
<FORM method="post" action="dbconnect.php">
 USERNAME<input type="text" name="first" id="first"><br>
<BR>MOVIE NAME<input type="text" name="mov" id="mov"><br>
<BR> <br>


<FORM method="post" action="dbconnect.php">
<select name="genre" id="genre" >  
<option> select</option>
<option> ⭐5 </option>
<option> ⭐4 </option>
<option> ⭐3 </option>
<option> ⭐2 </option>
<option> ⭐1 </option>
</select><br>
<input type="submit"> <br>
</FORM>

</HTML>
        

</FORM>
</html>
